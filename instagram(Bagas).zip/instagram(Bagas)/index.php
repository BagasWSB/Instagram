<?php
session_start();

if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}

include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";

$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi,$sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <link rel="shortcut icon" href="ig2.png">
    <title>Sportsgram</title>
</head>
<nav class="sticky-top" style="background-color: rgb(206, 58, 219);">
    <div class="nav-content">
      <div class="logo">
      <a class="navbar-light" href="#">
      <img src="ig2.png" width="60" height="60" class="d-inline-block" alt=""> Sportsgram</a>
      </div>
      <ul class="nav-links">
        <li><a class="btn btn-danger" href="logout.php"><i class="fa fa-sign-out"  style="font-size:24px"> Logout</i></a></li>
        <li><a href="tambah.php" type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-plus" style="font-size:24px"> Tambah</i></a>
</li>

      </ul>
    </div>
    
</nav>
<body>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-success">
        <h5 class="modal-title" id="exampleModalLabel">Tambah</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="" class="form-label">Gambar</label><br>
        <input type="file" name="gambar" id="" required><br><br>
     
        <label for="" class="form-label">Caption</label><br>
        <input class="form-control" type="text" name="caption" id="" autocomplete="off"><br>

        <label for="" class="form-label">Lokasi</label><br>
        <input class="form-control" type="text" name="lokasi" id="" autocomplete="off"><br><br>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input class="btn btn-success" type="submit" value="Simpan" name="simpan">
      </div>
      </form>
      </div>
    </div>
  </div>
</div>


<section id="header">
 
  <br><br>
      <?php while ($post = mysqli_fetch_assoc($query)) { ?>
        <center>
        <div class="card mt-5 mb-3" style="width: 30rem;">
        <div class="card-body">
        <tr>
        <div class="geeks">
        <th></th>
        <td><img class="card-img-top mb-3" src="images/<?= $post['gambar'] ?>" 
        alt="" width="185" height="570"></td>
        </div>
        <ul class="list-group list-group-flush">
        <li class="list-group-item">
        <th></th>
        <td><?=$post['caption']?></td>  
        </li>
        <li class="list-group-item">
        <th></th>
        <td><?=$post['lokasi']?></td> 
        </li>
         
        <li class="list-group-item">
        <td>
        <button onclick="confirmDelete(<?php echo $post['no'];?>)" href="hapus.php?no=<?= $post['no'] ?>" style="font-size:32px" type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button>
        <a style="font-size:32px" type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?= $post['no'] ?>" ><i class="fa fa-pencil"></i></a>
       
        </td>
        </li>
        </tr>      
     </div>
     </div>
        </center>
      <script>
      let nav = document.querySelector("nav");
      window.onscroll = function() {
      if(document.documentElement.scrollTop > 20){
        nav.classList.add("sticky");
      }else {
        nav.classList.remove("sticky");
      }
      }
      </script>
    
<center>
<div class="modal fade" id="editModal<?= $post['no'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-warning">
        <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">

        <label for="">Gambar</label><br>
        <input type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" ><br><br>
        <img src="images/<?= $post['gambar'] ?>" width="190" height="250" alt="" ><br><br>
        
        <label for="">Caption</label>
        <input  class="form-control" type="text" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off"><br>

        <label for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input class="btn btn-warning" type="submit" value="Update" name="update">
      </div>
      </form>
    </div>
  </div>
</div>
<br><br>
</center>
<script>
  function confirmDelete(postId) {
    Swal.fire({
      title: 'Anda Yakin?',
      text: "Anda tidak bisa mengembalikan ini ",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#7C81AD',
      confirmButtonText: 'Ya, Hapus!',
      cancelButtonText: 'Batal'
     
     }).then((result)=> {
      if (result.isConfirmed) {
        window.location.href = 'hapus.php?no=' + postId;
      }
     });
  }
</script>
<?php } ?>
</body>
</html>
    </section>
