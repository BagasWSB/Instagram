<?php
session_start();

if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}

include "koneksi.php";
require "functions.php";

if (isset($_POST['simpan'])) {

    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    $gambar = upload(); 
    
    $sql = "INSERT INTO post (gambar,caption,lokasi) VALUES ('$gambar', '$caption','$lokasi')";
    $query = mysqli_query($koneksi, $sql);

    if ($query) {
        header("location:index.php?tambah=sukses");
    } else {
        header("location:index.php?tambah=gagal");
    }
}


?>